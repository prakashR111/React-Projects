const OrderConfirmation = () =>{
    return (
    <>
        <div className="ordered-product">
            <div className="ordered-product-image">
                <img src="" alt="" />
            </div>
            <div></div>
        </div>
    </>
    );
}
export default OrderConfirmation;