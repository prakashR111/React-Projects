import { FOOTER_TEXT } from '../../constants/APP_CONSTANTS';
import './Footer.css';

const Footer = () => {
    return (
        <div className="footer">{FOOTER_TEXT.COPYRIGHT}</div>
        );
}
export default Footer;