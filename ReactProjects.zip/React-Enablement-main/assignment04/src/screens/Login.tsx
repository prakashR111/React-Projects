import LoginForm from "../containers/LoginForm/LoginForm";

const Login = () => {
  return (
    <>
      <LoginForm />
    </>
  );
};
export default Login;
