export const API_BASE_URL = "https://nijin-server.vercel.app/api/cineflex";

export const API_ENDPOINTS = {
    MOVIES: `${API_BASE_URL}/movies`,
    SHORT_TEASERS: `${API_BASE_URL}/short-teasers`,
};