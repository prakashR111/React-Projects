const RestaurantsPage = () => {
    return (
        <>
            <h1>Restaurants Page</h1>
        </>
    );
}
export default RestaurantsPage;