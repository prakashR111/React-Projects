const HotelsPage = () => {
    return (
        <>
            <h1>Hotels Page</h1>
        </>
    );
}
export default HotelsPage;