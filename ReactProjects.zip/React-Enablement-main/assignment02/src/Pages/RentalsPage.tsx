const RentalsPage = () => {
    return (
        <>
            <h1>Rentals Page</h1>
        </>
    );
}
export default RentalsPage;